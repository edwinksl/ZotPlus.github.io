#!/bin/bash

/usr/bin/curl "http://localhost:23119/better-bibtex/cayw?format=pandoc" | /usr/bin/pbcopy
