#!/bin/bash

curl http://localhost:23119/better-bibtex/cayw?keyprefix=@ | pbcopy
