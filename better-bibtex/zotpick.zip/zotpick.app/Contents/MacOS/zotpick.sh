#!/bin/bash

/usr/bin/curl http://localhost:23119/better-bibtex/cayw?keyprefix=@ | /usr/bin/pbcopy
